<?php

namespace App\Http\Controllers;

use App\Models\Requests;
use Illuminate\Http\Request;

class SportsController extends Controller
{
    //
    public function index(){

        $req=Requests::where('islibrary',2)->get();
        return view('sports.home',compact('req'));
    }
}
