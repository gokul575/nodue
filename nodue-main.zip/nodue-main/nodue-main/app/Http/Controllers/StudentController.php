<?php

namespace App\Http\Controllers;

use App\Models\Requests;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class StudentController extends Controller
{
    //


    public function index(){
        $request=DB::table('requests')
        ->where('rollno',  Auth::user()->rollno)->get();
        // dd($request);

        return view('student.home',compact('request'));
    }

    public function apply(){
        $r=DB::table('requests')->where('email',Auth::user()->email)->get();

if($r=="[]"){
    $user = Requests::firstOrCreate (['name' => Auth::user()->name,'email' => Auth::user()->email,'rollno' => Auth::user()->rollno,'branch' => Auth::user()->branch,'islibrary' => "1"]);
    $user->libraryrecived=new DateTime();
    $user->save();
      return redirect('/student')->with('info', 'Requested not successfully!');}
else{
    echo "<script type='text/javascript'>alert('you already');</script>";

        return redirect('/student')->with('info', 'Requested not successfully!');
    }

// if($r==null)
        // {
        //     $user = Requests::firstOrCreate (['name' => Auth::user()->name,'email' => Auth::user()->email,'rollno' => Auth::user()->rollno,'branch' => Auth::user()->branch,'islibrary' => 1]);
        //     $user->save();
        //   return redirect('/student')->with('info', 'Requested not successfully!');

        // }
        // else
        // {


        // }
        // $request=new Request();

        // if ($user->wasRecentlyCreated) {
        //     return redirect('/student')->with('info', 'Requested successfully!');

        //     // "firstOrCreate" didn't find the user in the DB, so it created it.
        // } else {

        //     // "firstOrCreate" found the user in the DB and fetched it.
        // }

        // $name=Auth::user()->name;
        // $email=Auth::user()->email;
        // $rollno=Auth::user()->rollno;
        // $branch=Auth::user()->branch;
        // $request->name=$name;
        // $request->email=$email;
        // $request->rollno=$rollno;
        // $request->branch=$branch;
        // $request->libraryrecived=Carbon::now();
        // $request->islibaray=1;

    }
}
