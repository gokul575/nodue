<?php

namespace App\Http\Controllers;

use App\Models\Requests;
use DateTime;
use Illuminate\Contracts\Session\Session as SessionSession;
use Illuminate\Http\Request;
use Session;

class LibraryController extends Controller
{
    //


    public function index(){
        $req=Requests::where('islibrary',1)->get();
        return view('library.home',compact('req'));
    }
    public function acceptatlib(Request $request,$id){
        $req=Requests::where('islibrary',1)->get();

        $a=Requests::where('rollno',$id)->get()->first();
        $a->islibrary="2";
        $a->libraryremark="no remarks";
        $a->librarystatuschanged=new DateTime();
        $a->save();

        $request->session()->put('success', "Approved successully" );;
        return redirect()->back();
    }
        public function rejectlib(Request $request,$id){

        $req=Requests::where('islibrary',1)->get();
        $a=Requests::where('rollno',$id)->get()->first();
$a->libraryremark=$request->libremark;
$a->islibrary="0";
$a->save();

        // $req=Requests::where('islibrary',1)->get();

        // $a=Requests::where('rollno',$id)->get()->first();
        // $a->libraryremark=$request->get('libremark');
        // $a->islibrary="0";
        // $a->save();
        $request->session()->put('error', "Rejected successfully" );;
        return redirect()->back();




    }
}
