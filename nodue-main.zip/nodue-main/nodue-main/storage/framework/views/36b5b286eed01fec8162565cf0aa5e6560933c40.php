<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">

        <div class="col-lg">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in as student !')); ?>

                    <?php echo e(Auth::user()->created_at->diffForHumans()); ?>



                    <div class="container">
                        <div class="row">
                            <div class="col-sm">

                                <form action="<?php echo e(route('sapply')); ?>" method="POST">

                                    <?php echo csrf_field(); ?>

                                    <button type='submit'>Request</button>



                                    </form>


                                    



                            </div>
                        </div>
                        <div class="row">

                            <h1 style="text-align: center">Status</h1>
                            <div class="col-sm">
                                <?php $__currentLoopData = $request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">Library status</th>
      <th scope="col">Library remark</th>

      <th scope="col">sports status</th>
      <th scope="col">sports remark</th>
      <th scope="col">acounts status</th>
      <th scope="col">accounts remark</th>
      <th scope="col">admin status</th>
      <th scope="col">admin remark</th>
      <th scope="col">lab status</th>
      <th scope="col">lab remark</th>
      <th scope="col">department status</th>
      <th scope="col">department remark</th>
      <th scope="col">Overall</th>
      <th scope="col">more</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td >
         <?php if($item->islibrary == 0): ?>
        Rejected
    <?php elseif($item->islibrary == 1): ?>
         Recived
        <?php elseif($item->islibrary == 2): ?>
         Accepted

    <?php endif; ?></td>
      <td><?php echo e($item->libraryremark); ?></td>
      <td >
        <?php if($item->issports == 1): ?>
       Accepted
   <?php elseif($item->issports == 0): ?>
       Not Accepted
   <?php endif; ?></td>
      <td><?php echo e($item->sportsremark); ?></td>
      <td >
        <?php if($item->isacounts == 1): ?>
       Accepted
   <?php elseif($item->isacounts == 0): ?>
       Not Accepted
   <?php endif; ?></td>
   <td>
       <?php echo e($item->accountsremark); ?>

   </td>
   <td>
    <?php if($item->isadmin == 1): ?>
    Accepted
<?php elseif($item->isadmin == 0): ?>
    Not Accepted
<?php endif; ?>
   </td>
   <td><?php echo e($item->adminremark); ?></td>
   <td>
    <?php if($item->islab == 1): ?>
    Accepted
<?php elseif($item->islab == 0): ?>
    Not Accepted
<?php endif; ?>
   </td>
   <td><?php echo e($item->labremark); ?></td>
   <td>
    <?php if($item->isdept == 1): ?>
    Accepted
<?php elseif($item->isdept == 0): ?>
    Not Accepted
<?php endif; ?>
   </td>
   <td>
       <?php echo e($item->deptremark); ?>

   </td>
   <td>
    <?php if($item->isaccepted==1): ?>
    Accepted
<?php elseif($item->isaccepted==0): ?>
    Not Accepted
<?php endif; ?>

   </td>
      <td><button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#yourModal" > View Detail</button>
      </td>

    </tr>

  </tbody>
</table>

    <div class="modal fade" id="yourModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"><?php echo e($item->name); ?> status</h5>

            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
              <li>
                Library Recived : <?php echo e(\Carbon\Carbon::parse($item->libraryrecived)->diffForHumans()); ?>


              </li>
              <li>
                Library Updated : <?php echo e(\Carbon\Carbon::parse($item->librarystatuschanged)->diffForHumans()); ?>


              </li>
              <li>
                Sports recived: <?php echo e(\Carbon\Carbon::parse($item->sportsrecived)->diffForHumans()); ?>

              </li>
              <li>
                Sports updated: <?php echo e(\Carbon\Carbon::parse($item->sportsstatuschanged)->diffForHumans()); ?>

              </li>
              <li>
                Accounts recived : <?php echo e(\Carbon\Carbon::parse($item->accountsrecived)->diffForHumans()); ?>

              </li>
              <li>
                Accounts updated:  <?php echo e(\Carbon\Carbon::parse($item->accountsstatuschanged)->diffForHumans()); ?>

              </li>
              <li>
                Admin recived: <?php echo e(\Carbon\Carbon::parse($item->adminrecived)->diffForHumans()); ?>

              </li>
              <li>
                Admin updated: <?php echo e(\Carbon\Carbon::parse($item->adminstatuschanged)->diffForHumans()); ?>

              </li>
              <li>
                Labs recived: <?php echo e(\Carbon\Carbon::parse($item->labsrecived)->diffForHumans()); ?>

              </li>
              <li>
                Labs updated: <?php echo e(\Carbon\Carbon::parse($item->labsstatuschanged)->diffForHumans()); ?>

              </li>
              <li>
                Department Recived: <?php echo e(\Carbon\Carbon::parse($item->deptsrecived)->diffForHumans()); ?>

              </li>
              <li>
                Department updated: <?php echo e(\Carbon\Carbon::parse($item->deptsstatuschanged)->diffForHumans()); ?>

              </li>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nodue-main\nodue-main\resources\views/student/home.blade.php ENDPATH**/ ?>