<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRequestsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('requests', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email');
            $table->string('rollno');
            $table->string('branch');
            $table->string('islibrary');
            $table->string('libraryremark')->nullable();
             $table->timestamp('libraryrecived')->nullable();
             $table->timestamp('librarystatuschanged')->nullable();


            $table->integer('issports')->default(0);
            $table->string('sportsremark')->nullable();
            $table->timestamp('sportsrecived')->nullable();
            $table->timestamp('sportsstatuschanged')->nullable();


            $table->integer('isacounts')->default(0);
            $table->string('accountsremark')->nullable();
            $table->timestamp('accountsrecived')->nullable();
            $table->timestamp('accountsstatuschanged')->nullable();


            $table->integer('isadmin')->default(0);
            $table->string('adminremark')->nullable();
            $table->timestamp('adminrecived')->nullable();
            $table->timestamp('adminstatuschanged')->nullable();


            $table->integer('islab')->default(0);
            $table->string('labremark')->nullable();
            $table->timestamp('labsrecived')->nullable();
            $table->timestamp('labsstatuschanged')->nullable();


            $table->integer('isdept')->default(0);
            $table->string('deptremark')->nullable();


            $table->timestamp('deptsrecived')->nullable();
            $table->timestamp('deptsstatuschanged')->nullable();



            $table->boolean('isaccepted')->default(0);


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('requests');
    }
}
