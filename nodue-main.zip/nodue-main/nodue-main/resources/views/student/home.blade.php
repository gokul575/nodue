@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">

        <div class="col-lg">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('You are logged in as student !') }}
                    {{Auth::user()->created_at->diffForHumans()}}


                    <div class="container">
                        <div class="row">
                            <div class="col-sm">

                                <form action="{{route('sapply')}}" method="POST">

                                    @csrf

                                    <button type='submit'>Request</button>



                                    </form>


                                    {{-- <button type="button" class="btn btn-success" value="submit">Request</button> --}}



                            </div>
                        </div>
                        <div class="row">

                            <h1 style="text-align: center">Status</h1>
                            <div class="col-sm">
                                @foreach ($request as $item)

<table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">Library status</th>
      <th scope="col">Library remark</th>

      <th scope="col">sports status</th>
      <th scope="col">sports remark</th>
      <th scope="col">acounts status</th>
      <th scope="col">accounts remark</th>
      <th scope="col">admin status</th>
      <th scope="col">admin remark</th>
      <th scope="col">lab status</th>
      <th scope="col">lab remark</th>
      <th scope="col">department status</th>
      <th scope="col">department remark</th>
      <th scope="col">Overall</th>
      <th scope="col">more</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td >
         @if($item->islibrary == 0)
        Rejected
    @elseif($item->islibrary == 1)
         Recived
        @elseif($item->islibrary == 2)
         Accepted

    @endif</td>
      <td>{{$item->libraryremark}}</td>
      <td >
        @if($item->issports == 1)
       Accepted
   @elseif($item->issports == 0)
       Not Accepted
   @endif</td>
      <td>{{$item->sportsremark}}</td>
      <td >
        @if($item->isacounts == 1)
       Accepted
   @elseif($item->isacounts == 0)
       Not Accepted
   @endif</td>
   <td>
       {{$item->accountsremark}}
   </td>
   <td>
    @if($item->isadmin == 1)
    Accepted
@elseif($item->isadmin == 0)
    Not Accepted
@endif
   </td>
   <td>{{$item->adminremark}}</td>
   <td>
    @if($item->islab == 1)
    Accepted
@elseif($item->islab == 0)
    Not Accepted
@endif
   </td>
   <td>{{$item->labremark}}</td>
   <td>
    @if($item->isdept == 1)
    Accepted
@elseif($item->isdept == 0)
    Not Accepted
@endif
   </td>
   <td>
       {{$item->deptremark}}
   </td>
   <td>
    @if($item->isaccepted==1)
    Accepted
@elseif($item->isaccepted==0)
    Not Accepted
@endif

   </td>
      <td><button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#yourModal" > View Detail</button>
      </td>

    </tr>

  </tbody>
</table>

    <div class="modal fade" id="yourModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">{{$item->name}} status</h5>

            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
              <li>
                Library Recived : {{ \Carbon\Carbon::parse($item->libraryrecived)->diffForHumans()}}

              </li>
              <li>
                Library Updated : {{ \Carbon\Carbon::parse($item->librarystatuschanged)->diffForHumans()}}

              </li>
              <li>
                Sports recived: {{ \Carbon\Carbon::parse($item->sportsrecived)->diffForHumans()}}
              </li>
              <li>
                Sports updated: {{ \Carbon\Carbon::parse($item->sportsstatuschanged)->diffForHumans()}}
              </li>
              <li>
                Accounts recived : {{ \Carbon\Carbon::parse($item->accountsrecived)->diffForHumans()}}
              </li>
              <li>
                Accounts updated:  {{ \Carbon\Carbon::parse($item->accountsstatuschanged)->diffForHumans()}}
              </li>
              <li>
                Admin recived: {{ \Carbon\Carbon::parse($item->adminrecived)->diffForHumans()}}
              </li>
              <li>
                Admin updated: {{ \Carbon\Carbon::parse($item->adminstatuschanged)->diffForHumans()}}
              </li>
              <li>
                Labs recived: {{ \Carbon\Carbon::parse($item->labsrecived)->diffForHumans()}}
              </li>
              <li>
                Labs updated: {{ \Carbon\Carbon::parse($item->labsstatuschanged)->diffForHumans()}}
              </li>
              <li>
                Department Recived: {{ \Carbon\Carbon::parse($item->deptsrecived)->diffForHumans()}}
              </li>
              <li>
                Department updated: {{ \Carbon\Carbon::parse($item->deptsstatuschanged)->diffForHumans()}}
              </li>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
@endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
