@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('You are logged in as Library dept !') }}
                    <div class="container">
                        @if( Session::has("success") )
  <div class="alert alert-success alert-block" role="alert">
  <button class="close" data-dismiss="alert"></button>
  {{ Session::get("success") }}
 </div>
 @endif
 @if( Session::has("error") )
  <div class="alert alert-danger alert-block" role="alert">
  <button class="close" data-dismiss="alert"></button>
  {{ Session::get("error") }}
 </div>
 @endif
 <div id="successMessage"></div>

                        <h1 style="text-align: center;">Requests</h1>

                        <div class="row">
                           <table class="table">
                               <thead>
                                   <tr>
                                       <th>Name</th>
                                       <th>RollNo</th>
                                       <th>Branch</th>
                                     <th>Options </th>

                                   </tr>
                               </thead>
                               <tbody>
                               @foreach($req as $re)
                                   <tr>
                                       <td>{{$re->name}}</td>
                                       <td>{{$re->rollno}}</td>
                                       <td>{{$re->branch}}</td>
                                       <td class="td-actions">
                                        <form action="{{route('libaccept',$re->rollno)}}" method="POST">
                                            @csrf
                                            @method('GET')

                                            <div class="radio">


                                            <button type="submit" rel="tooltip" class="btn btn-success">
                                                <i class="material-icons">Approve</i>
                                            </button>

                                        </form>

                                        <form action="{{route('libreject',$re->rollno)}}" method="POST">
                                            @csrf
                                            @method('pOST')

                                            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal">
                                                Reject
                                              </button>
                                              <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                  <div class="modal-content">
                                                    <div class="modal-header">
                                                      <h5 class="modal-title" id="exampleModalLabel">{{$re->name}}'s rejection remark</h5>
                                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                      </button>
                                                    </div>
                                                    <div class="modal-body">
                                                    <div class="container">
                                                        <div class="row">

                                                                <form action="" method="POST">
                                                                    <div class="form-group">
                                                                        <label for="exampleFormControlTextarea1">Remark</label>
                                                                        <textarea class="form-control" id="exampleFormControlTextarea1"  name="libremark" rows="3">
                                                                            {{$re->libraryremark}}
                                                                        </textarea>
                                                                      </div>

                                                                </form>

                                                        </div>
                                                    </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                      <button type="submit" class="btn btn-success">Confirm</button>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                        </form>



                                       </td>
                                   </tr>


                                   @endforeach

                               </tbody>

                           </table>



                                                   </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous">
setTimeout(function() {
    $('#successMessage').fadeOut('fast');
}, 3000);
</script>




@endsection
